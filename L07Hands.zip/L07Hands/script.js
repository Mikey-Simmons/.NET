function regexChecker() {
    let firstName = document.getElementById('First').value;
    let lastName = document.getElementById('Last').value;
    let firstnRegex = /^[a-zA-Z]/;

    if (firstName.match && firstName.match){
    alert ("Yay! Your inputs were all correct!");
    console.log(true);
    }
    else{
        alert ("Yay! Your inputs were all correct!");
        console.log(false)
    }
    
     

   
    
    
}