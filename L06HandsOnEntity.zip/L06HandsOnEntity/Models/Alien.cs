namespace L06HandsOnEntity.Models
{
    public class Alien{
        public int Id{
            get; set;
        }
        public int numberOfArms{
            get;
            set;
        }
        public int numberOfHeads{
            get;
            set;
        }
        public int numberOfLegs{
            get; set;
        }
        public DateTime BirthDate{
            get;set;
        }
        public string PlanetOfOrigin{
            get;
            set;
        }


    }
    
}
