﻿
Console.WriteLine("First Integer:");
string x = Console.ReadLine();
Console.WriteLine("Second Integer:");
string y = Console.ReadLine();
int i = Convert.ToInt32(x);
int j = Convert.ToInt32(y);
int z = i + j;
Console.WriteLine("The sum of " +i + " + " +j +" = " + z +"!");