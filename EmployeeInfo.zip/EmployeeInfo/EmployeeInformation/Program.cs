﻿string name;
string bday;
string phone;
string email;

name = "Lucinda Potter";
bday = "06/24/1992";
phone = "312-982-1010";
email = "ewoz@woz-u.com";

Console.Write($"{name}, DOB: {bday}, phone number: {phone}, email: {email}");
