 public class Vacation
{
    public long Id { get; set; }
    public string Name { get; set; }
    public bool Visited { get; set; }
}